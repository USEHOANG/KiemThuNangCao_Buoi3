package com.example.kiemthunangcao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KiemthunangcaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KiemthunangcaoApplication.class, args);
	}

}
