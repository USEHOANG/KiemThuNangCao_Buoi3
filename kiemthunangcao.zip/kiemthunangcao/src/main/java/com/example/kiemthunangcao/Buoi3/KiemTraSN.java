package com.example.kiemthunangcao.Buoi3;

public class KiemTraSN {
    public boolean KTSN(String input){
        try {
            Integer.parseInt(input);
            return true;
        }catch (NumberFormatException e){
            return false;
        }
    }
}
