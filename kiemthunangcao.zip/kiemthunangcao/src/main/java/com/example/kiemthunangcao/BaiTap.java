package com.example.kiemthunangcao;

public class BaiTap {
    public static int tinhTong(int a, int b) {
        return a + b;
    }

    public static int tinhHieu(int a, int b) {
        return a - b;
    }

    public static int tinhTich(int a, int b) {
        return a * b;
    }

    public static double tinhThuong(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Số chia không được bằng 0");
        }
        return (double) a / b;
    }

    public static double tinhTrungBinhCong(int a, int b) {
        return (double) (a + b) / 2;
    }
}
