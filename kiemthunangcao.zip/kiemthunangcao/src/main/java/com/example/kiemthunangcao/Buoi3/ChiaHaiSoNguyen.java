package com.example.kiemthunangcao.Buoi3;

public class ChiaHaiSoNguyen {
    public int tichSoNguyen(int a, int b){
        if (b==0){
            throw new ArithmeticException("Khong the chia cho 0");
        }
        return a/b;
    }
}
