package com.example.kiemthunangcao.Buoi3;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class TestSN {
    @Test
    public void testSoNguyen(){
        KiemTraSN validate = new KiemTraSN();
        assertTrue(validate.KTSN("123"));
        assertTrue(validate.KTSN("-456"));
        assertTrue(validate.KTSN("0"));
        assertTrue(validate.KTSN("12.34"));
        assertTrue(validate.KTSN(""));
        assertTrue(validate.KTSN(" "));
        assertTrue(validate.KTSN("!@#$"));
        assertTrue(validate.KTSN("0000123"));
        assertTrue(validate.KTSN("abc"));
        assertTrue(validate.KTSN(" 123 "));
    }
}
