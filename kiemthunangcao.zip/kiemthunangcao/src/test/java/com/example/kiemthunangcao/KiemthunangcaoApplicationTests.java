package com.example.kiemthunangcao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KiemthunangcaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
