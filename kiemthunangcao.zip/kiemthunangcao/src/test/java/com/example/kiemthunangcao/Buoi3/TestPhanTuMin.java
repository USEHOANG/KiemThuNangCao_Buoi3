package com.example.kiemthunangcao.Buoi3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class TestPhanTuMin {
    @Test
    public void testFindMinElement() {
        PhanTuNhoNhat finder = new PhanTuNhoNhat();
        assertEquals(1, finder.PhanTuMin(new int[]{3, 5, 1, 9}));
        assertEquals(-4, finder.PhanTuMin(new int[]{-1, -2, -4, 0}));
        assertThrows(IllegalArgumentException.class, () -> finder.PhanTuMin(new int[]{}));
    }
}
