package com.example.kiemthunangcao.Buoi3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
public class TestChiaHaiSN {
    @Test
    public void testChia(){
        ChiaHaiSoNguyen validate = new ChiaHaiSoNguyen();
        assertEquals(5,validate.tichSoNguyen(10,2));
        assertEquals(-5,validate.tichSoNguyen(-10,2));
        assertEquals(0,validate.tichSoNguyen(0,10));
        assertEquals(123,validate.tichSoNguyen(123,1));
        assertEquals(-123,validate.tichSoNguyen(123,-1));
        assertEquals(5,validate.tichSoNguyen(-10,-2));
        assertThrows(ArithmeticException.class,() -> validate.tichSoNguyen(10,0));
        assertEquals(1,validate.tichSoNguyen(Integer.MAX_VALUE, Integer.MAX_VALUE));
        assertEquals(1,validate.tichSoNguyen(Integer.MIN_VALUE, Integer.MIN_VALUE));
    }
}
